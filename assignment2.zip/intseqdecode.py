import sys
import os
FILE = sys.argv[1]
INDEX = 0
ALL = {}
OUTFILE = 'output_intseqdecode.txt'

class Root:
    def __init__(self, x):
        self.x = x
        self.lNode = None
        self.rNode = None

class FBT:
    memo = {0 : [], 1 : [Root(0)]}
    def __init__(self):
        self.binary = ''
        self.saveDict = {}
        self.sortBinStr = []

    def allFBT(self, N):
        if N not in FBT.memo:
            ans = []
            for x in range(N):
                y = N - x - 1
                for lNode in self.allFBT(x):
                    for rNode in self.allFBT(y):
                        temp = Root(1)
                        temp.lNode = lNode
                        temp.rNode = rNode
                        ans.append(temp)
                FBT.memo[N] = ans

        return FBT.memo[N]

    def pre(self, root):
        if root == None:
            return
        self.binary += str(int(not root.x))
        self.pre(root.lNode)
        self.pre(root.rNode)
    
    def save2Dict(self, bstr):
        global ALL
        global INDEX
        INDEX += 1
        ALL[bstr] = INDEX

    def save(self, N):
        nodes = self.allFBT(N)
        self.sortBinStr = []
        for node in nodes:
            self.binary = ''
            self.pre(node)
            self.sortBinStr.append(self.binary)
        self.sortBinStr.sort(key = self.key)
        for bstr in self.sortBinStr:
            self.save2Dict(bstr)

    def key(self, val):
        return int(val, 2)

class Decode:
    def __init__(self):
        self.binary = ''
        self.res = []
    
    def read(self):
        with open(FILE, 'r') as fobject:
            self.binary = fobject.read()

    def decode(self):
        self.read()
        s = ''
        for bStr in self.binary:
            s += bStr
            if s in ALL:
                self.res.append(ALL[s])
                s = ''
        
        return self.res

if __name__ == '__main__':
    for i in range(1, 23, 2):
        FBT().save(i)

    result = Decode().decode()

    if os.path.exists(OUTFILE):
        os.remove(OUTFILE)

    with open(OUTFILE, 'a+') as fobject:
        for i in range(len(result)):
            if i == len(result) - 1:
                fobject.write(str(result[i]))
            else:
                fobject.write(str(result[i]) + ', ')

