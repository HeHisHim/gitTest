import sys
import os
NUM = 2 * int(sys.argv[1]) + 2
INDEX = 0
FILE = 'output_enumerate.txt'

class Root:
    def __init__(self, x):
        self.x = x
        self.lNode = None
        self.rNode = None

class FBT:
    memo = {0 : [], 1 : [Root(0)]}

    def __init__(self):
        self.binary = ''
        self.sortBinStr = []
    
    def allFBT(self, N):
        if N not in FBT.memo:
            ans = []
            for x in range(N):
                y = N - x - 1
                for lNode in self.allFBT(x):
                    for rNode in self.allFBT(y):
                        temp = Root(1)
                        temp.lNode = lNode
                        temp.rNode = rNode
                        ans.append(temp)
                FBT.memo[N] = ans

        return FBT.memo[N]

    def pre(self, root):
        if root == None:
            return
        self.binary += str(int(not root.x))
        self.pre(root.lNode)
        self.pre(root.rNode)

    def output(self, bstr):
        global INDEX
        INDEX += 1
        with open(FILE, 'a+') as fobject:
            fobject.write(str(INDEX) + '\t\t' + bstr + '\n')

    def enumerate(self, N):
        nodes = self.allFBT(N)
        self.sortBinStr = []
        for n in nodes:
            self.binary = ''
            self.pre(n)
            self.sortBinStr.append(self.binary)
        self.sortBinStr.sort(key = self.key)
        for bstr in self.sortBinStr:
            self.output(bstr)

    def key(self, val):
        return int(val, 2)


if __name__ == '__main__':
    if os.path.exists(FILE):
        os.remove(FILE)

    for index in range(1, NUM, 2):
        FBT().enumerate(index)
