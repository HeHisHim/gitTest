import random
import sys
import os
import math

NUM = int(sys.argv[1])
FILE = 'output_factors.txt'

class MRAlgorithm:
    def __init__(self, checkVal):
        self.checkVal = checkVal

    def output(self):
        arr = []
        save = {}
        tally = 0
        all = 1
        finalNum = 0
        outputStr = ''
        outputStr += (str(self.checkVal) + '\t\t')
        while self.checkVal != 1:
            for i in range(2, int(self.checkVal + 1)):
                if self.checkVal % i == 0:
                    arr.append(i)
                    self.checkVal = self.checkVal / i
                    break
        tmpset = set(arr)
        for tmp in tmpset:
            tally += 1
            save[tmp] = arr.count(tmp)
        
        finalNum = tmp

        with open(FILE, 'r+') as file:
            for key, value in save.items():
                if all >= tally:
                    break
                all += 1
                outputStr += (str(key) + ' ^ ' + str(value) + ' x ')
            outputStr += (str(finalNum) + ' ^ ' + str(save[finalNum]))
            content = file.read()
            file.seek(0, 0)
            file.write(outputStr + '\n' + content)

    def solution(self, key = 100):
        if 2 == self.checkVal or 3 == self.checkVal:
            return True
        if self.checkVal < 2 or self.checkVal % 2 == 0:
            return False

        def checkPrimeNumber(i, j, k, checkVal):
            x = pow(i, k, checkVal)
            if x == 1:
                return True
            for _ in range(j - 1):
                if x == checkVal - 1:
                    return True
                x = pow(x, 2, checkVal)
            return x == checkVal - 1

        j = 0
        k = self.checkVal - 1

        while k % 2 == 0:
            k >>= 1
            j += 1

        for _ in range(key):
            i = random.randrange(2, self.checkVal - 1)
            if not checkPrimeNumber(i, j, k, self.checkVal):
                return False
        return True

if __name__ == '__main__':
    if os.path.exists(FILE):
        os.remove(FILE)
    with open(FILE, 'a+') as file:
        pass
    theNum = 0
    for x in range(NUM - 1, 1, -1):
        if MRAlgorithm(x).solution():
            theNum += 1
            if 101 == theNum:
                break
            MRAlgorithm(x + 1).output()
