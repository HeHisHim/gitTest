#include <stdio.h>

void find_two_largest(const int *a, int n, int *largest, int *second_largest)
{
    const int *p, *pMax, *pSecMax;
    p = pMax = pSecMax = a;

    for (; p < a + n; p++) 
    {
        if (*p > *pMax) 
        {
            pSecMax = pMax;
            pMax = p;
        } 
        else if (*p > *pSecMax) 
        {
            pSecMax = p;
        }
    }

    *largest = *pMax;
    *second_largest = *pSecMax;
}

int main(int argc, char const *argv[])
{
    int a[6] = {-1, 8, 5, 7, 1, 6};
    int largest, second_largest;
    find_two_largest(a, 6, &largest, &second_largest);

    printf("%d %d\n", largest, second_largest);
    return 0;
}

