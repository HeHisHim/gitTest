#include <stdio.h>

void split_time(long total_sec, int *hr, int *min, int *sec)
{
    *hr = total_sec / 3600;
    *min = total_sec % 3600 / 60;
    *sec = total_sec % 3600 % 60;
}

int main(int argc, char const *argv[])
{
    int time = 86399;
    int hr, min, sec;
    split_time(time, &hr, &min, &sec);

    printf("%d : %d : %d\n", hr, min, sec);
    return 0;
}


