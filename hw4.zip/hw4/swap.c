#include <stdio.h>

void swap(int *p, int *q)
{
    int temp;
    temp = *p;
    *p = *q;
    *q = temp;
}

int main(int argc, char const *argv[])
{
    int a = 10;
    int b = 20;
    swap(&a, &b);

    printf("%d %d\n", a, b);
    return 0;
}

