#include <stdio.h>

int *find_largest(int a[], int n)
{
    int maxIndex = 0;
    int index;

    for(index = 0; index < n; index++)
    {
        if( a[maxIndex] < a[index])
        {
            maxIndex = index;
        }
    }

    return (a + maxIndex);
}

int main(int argc, char const *argv[])
{
    int a[5] = {-9, 9, 13, 35, 6};
    int *p;
    p = find_largest(a, 5);
    printf("%d\n", *p);
    return 0;
}
