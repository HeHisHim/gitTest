#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

void judgeFileName(char const* fileName)
{
    char* judge = ".rle";
    int length = strlen(fileName);
    for(int x = length - 4, y = 0; x < length; x++, y++)
    {
        if(fileName[x] != judge[y])
        {
            printf("File does not end in .rle\n");
            exit(EXIT_FAILURE);
        }
    }
}

void judgeMagicNumber(char* arr)
{
    if(!(0x21 == arr[0] && 0x52 == arr[1] && 0x4c == arr[2] && 0x45 == arr[3]))
    {
        printf("No Magic Number\n");
        exit(EXIT_FAILURE);
    }
}

int main(int argc, char const *argv[])
{
    FILE* fp = NULL;
    char* analysis = NULL;
    char write2File[255];
    int count = 0;
    char ch;
    int lenght = 0;
    int index = 0;

    if (2 != argc)
    {
        fprintf(stderr, "Usage: %s [file]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    judgeFileName(argv[1]);

    if(!(fp = fopen(argv[1], "rb")))
    {
        printf("file cannot be opened to read\n");
        exit(EXIT_FAILURE);
    }

    while(!feof(fp))
    {
        ch = fgetc(fp);
        count++;
    }
    rewind(fp);
    analysis = (char *)malloc(sizeof(char) * count + 1);
    count = 0;

    while(!feof(fp))
    {
        ch = fgetc(fp);
        analysis[count] = ch;
        count++;
    }

    judgeMagicNumber(analysis);

    for(int i = 4; i < count; i += 2)
    {
        index = analysis[i];
        for(int j = 0; j < index; j++)
        {
            write2File[lenght] = analysis[i + 1];
            lenght++;
        }
    }

    unsigned long fileNameLengh = strlen(argv[1]) - 4;
    char targetFile[fileNameLengh];
    strncpy(targetFile, argv[1], fileNameLengh);
    targetFile[fileNameLengh] = '\0';

    if(!(fp = fopen(targetFile, "wb")))
    {   
        printf("The file to be written cannot be opened\n");
        exit(EXIT_FAILURE);
    }
    fwrite(write2File, sizeof(char), lenght, fp);

    return 0;
}
