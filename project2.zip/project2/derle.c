#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int cmp(char* x, char* y)
{
    printf("x = %s, y = %s, \n", x, y);
    int index = 0;
    if(strlen(x) != strlen(y))
    {
        return 1;
    }
    while('\0' != x[index] || '\0' != y[index])
    {
        if(x[index] != y[index])
        {
            return 1;
        }
        index++;
    }
    return 0;
}

void judgeFileName(char const* fileName)
{
    char* judge = ".rle";
    int length = strlen(fileName);
    for(int x = length - 4, y = 0; x < length; x++, y++)
    {
        if(fileName[x] != judge[y])
        {
            printf("File does not end in .rle\n");
            exit(EXIT_FAILURE);
        }
    }
}

int main(int argc, char const *argv[])
{
    FILE* fp = NULL;
    char* magicNum = "21 52 4C 45 ";
    char ch;
    char curBuffer[3];
    char* ret = NULL;
    char* reduction = NULL;
    int index = 0;
    int total = 1;

    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s [file]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    judgeFileName(argv[1]);

    if(!(fp = fopen(argv[1], "r")))
    {
        printf("file cannot be opened\n");
        exit(EXIT_FAILURE);
    }
    while (EOF != (ch = fgetc(fp)))
    {
        if(' ' == ch)
        {
            continue;
        }
        if(2 != index)
        {
            curBuffer[index] = ch;
            curBuffer[index + 1] = '\0';
            index++;
        }
        if(2 == index)
        {
            ret = (char *)realloc(ret, (sizeof(curBuffer) + 3) * total);
            if(1 == total)
            {
                sprintf(ret, "%s ", curBuffer);
            }
            else
            {
                char target[strlen(curBuffer) + 3];
                sprintf(target, "%s ", curBuffer);
                strcat(ret, target);
            }
            index = 0;
            total++;
            
        }
    }

    unsigned long fileNameLengh = strlen(argv[1]) - 4;
    char targetFile[fileNameLengh];
    strncpy(targetFile, argv[1], fileNameLengh);
    targetFile[fileNameLengh] = '\0';

    char judgeMagicNum[13];
    strncpy(judgeMagicNum, ret, 12);
    judgeMagicNum[12] = '\0';
    if(strcmp(judgeMagicNum, magicNum))
    {
        printf("No Magic Number\n");
        exit(EXIT_FAILURE);
    }
    
    char dest[strlen(ret) - 12 + 1];
    strncpy(dest, ret + 12, strlen(ret) - 12);
    dest[strlen(ret) - 12] = '\0';
    const char* s = " ";
    char* token;
    token = strtok(dest, s);
    int control = 0;
    int bufferNum = 0;
    int allByte = 0;

    while(NULL != token)
    {
        if(0 == control)
        {
            bufferNum = strtol(token, NULL, 16);
            control++;
        }
        else if(1 == control)
        {
            allByte += sizeof(token) * bufferNum;
            reduction = (char *)realloc(reduction, allByte);
            for(int n = 0; n < bufferNum; n++)
            {
                char target[strlen(token) + 1];
                sprintf(target, "%s ", token);
                strcat(reduction, target);
            }
            control = 0;
        }
        token = strtok(NULL, s);
    }
    printf("write to %s: %s\n", targetFile, reduction);

    if(!(fp = fopen(targetFile, "w")))
    {   
        printf("txt file cannot be opened\n");
        exit(EXIT_FAILURE);
    }
    fprintf(fp, "%s", reduction);

    free(ret);
    free(reduction);
    fclose(fp);
    return 0;
}
