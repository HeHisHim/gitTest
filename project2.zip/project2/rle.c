#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int main(int argc, char const *argv[])
{
    FILE *fp = NULL;
    char ch;
    int count = 0;
    char *ret = NULL;
    char write2File[255];
    int num = 1;
    char curRet;
    int index = 1;
    int lenght = 4;

    write2File[0] = 0x21;
    write2File[1] = 0x52;
    write2File[2] = 0x4c;
    write2File[3] = 0x45;

    if (2 != argc)
    {
        fprintf(stderr, "Usage: %s [file]\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    if (!(fp = fopen(argv[1], "rb")))
    {
        printf("file cannot be opened\n");
        exit(EXIT_FAILURE);
    }

    while (!feof(fp))
    {
        ch = fgetc(fp);
        count++;
    }
    rewind(fp);
    ret = (char *)malloc(sizeof(char) * count);
    count = 0;

    while (!feof(fp))
    {
        ch = fgetc(fp);
        ret[count] = ch;
        count++;
    }

    curRet = ret[0];
    while (index < count)
    {
        if (curRet == ret[index])
        {
            num++;
        }
        else
        {
            if(0xFF < num)
            {
                while(0xFF < num)
                {
                    write2File[lenght] = 0xFF;
                    lenght++;
                    write2File[lenght] = curRet;
                    lenght++;
                    num -= 0xFF;
                }
                write2File[lenght] = num;
                lenght++;
                write2File[lenght] = curRet;
                lenght++;
                curRet = ret[index];
                num = 1;
            }
            else
            {
                write2File[lenght] = num;
                lenght++;
                write2File[lenght] = curRet;
                lenght++;
                curRet = ret[index];
                num = 1;
            }
        }
        index++;
    }

    FILE *pFile = NULL;
    char fileName[strlen(argv[1]) + 5];
    strcpy(fileName, argv[1]);
    strcat(fileName, ".rle");
    if (!(pFile = fopen(fileName, "wb")))
    {
        printf("rle file cannot be opened\n");
        exit(EXIT_FAILURE);
    }

    fwrite(write2File, sizeof(char), lenght, pFile);

    fclose(pFile);
    fclose(fp);
    free(ret);
    return 0;
}
