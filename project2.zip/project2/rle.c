#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define min(a, b)(a < b ? a : b)

int cmp(char* x, char* y)
{
    int index = 0;
    if(strlen(x) != strlen(y))
    {
        return 1;
    }
    while('\0' != x[index] || '\0' != y[index])
    {
        if(x[index] != y[index])
        {
            return 1;
        }
        index++;
    }
    return 0;
}

int main(int argc, char const *argv[])
{
    FILE* fp = NULL;
    char* magicNum = "21 52 4C 45 ";
    char ch;
    char curBuffer[3];
    char nextBuffer[3];
    char* ret = NULL;
    int index = 0;
    int next = 0;
    int count = 1;
    int total = 1;

    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s [file]\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    if(!(fp = fopen(argv[1], "r")))
    {
        printf("file cannot be opened\n");
        exit(EXIT_FAILURE);
    }

    while (EOF != (ch = fgetc(fp)))
    {
        if(' ' == ch)
        {
            continue;
        }
        if(2 != index)
        {
            curBuffer[index] = ch;
            curBuffer[index + 1] = '\0';
            index++;
            continue;
        }
        if(2 != next)
        {
            nextBuffer[next] = ch;
            nextBuffer[next + 1] = '\0';
            next++;
        }
        if(2 == next)
        {
            if(!cmp(curBuffer, nextBuffer))
            {
                count++;
                next = 0;
            }
            else
            {
                ret = (char *)realloc(ret, (sizeof(curBuffer) + 3) * total);


                while(0xFF < count)
                {
                    char target[strlen(curBuffer) + 3];
                    sprintf(target, "%02X %s ", min(0xFF, count), curBuffer);
                    strcat(ret, target);
                    count -= 0xFF;
                    total++;
                    ret = (char *)realloc(ret, (sizeof(curBuffer) + 3) * total);
                }
                

                char target[strlen(curBuffer) + 3];
                sprintf(target, "%02X %s ", count, curBuffer);
                strcat(ret, target);
                strcpy(curBuffer, nextBuffer);
                count = 1;
                next = 0;
                total++;
            }
        }
    }

    ret = (char *)realloc(ret, (sizeof(curBuffer) + 3) * total);
    while(0xFF < count)
    {
        char target[strlen(curBuffer) + 3];
        sprintf(target, "%02X %s ", min(0xFF, count), curBuffer);
        strcat(ret, target);
        count -= 0xFF;
        total++;
        ret = (char *)realloc(ret, (sizeof(curBuffer) + 3) * total);
    }

    char target[strlen(curBuffer) + 3];
    sprintf(target, "%02X %s", count, curBuffer);
    strcat(ret, target);
    printf("write to %s.rle:  %s\n", argv[1], ret);

    char fileName[strlen(argv[1]) + 5];
    strcpy(fileName, argv[1]);
    strcat(fileName, ".rle");
    if(!(fp = fopen(fileName, "w")))
    {   
        printf("rle file cannot be opened\n");
        exit(EXIT_FAILURE);
    }
    fprintf(fp, "%s", magicNum);
    fprintf(fp, "%s", ret);

    free(ret);
    fclose(fp);
    return 0;
}
