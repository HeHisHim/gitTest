#include <stdio.h>

int main(void)
{
  printf("What is the question.\n");
  return 0;
}