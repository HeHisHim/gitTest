#include <stdio.h>
#include <stdlib.h>
int main(int argc, char const *argv[])
{
    short x = 32;
    int* p = NULL;
    p = malloc(x);
    if(!p)
    {
        printf("not malloc\n");
        return 0;
    }
    printf("\n");
    free(p);
    return 0;
}

// (setenv LD_PRELOAD "./mymalloc.so"; ./intc; unsetenv LD_PRELOAD)
// LD_PRELOAD = "./mymalloc.so" ./intc
// gcc -DRUNTIME -shared -fpic -o mymalloc.so mymalloc.c -ldl
// export LD_PRELOAD="./mymalloc.so"; ./intc; unset LD_PRELOAD
// gcc -DRUNTIME --shared -fpic -o mymalloc.so mymalloc.c -ldl