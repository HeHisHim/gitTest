#ifdef RUNTIME
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <sys/_types/_size_t.h>


void *malloc(size_t size)
{
    void* (*mallocp)(size_t size);
    char* error;

    mallocp = dlsym(RTLD_NEXT, "malloc");
    if((error = dlerror()) != NULL)
    {
        fputs(error, stderr);
        exit(EXIT_FAILURE);
    }

    char* ptr = mallocp(size);
    printf("malloc(%d) =  %p\n", (int)size, ptr);

    return ptr;
}

void free(void* ptr)
{
    void (*freep)(void* ) = NULL;
    char* error;

    if(!ptr)
    {
        return;
    }

    freep = dlsym(RTLD_NEXT, "free");
    if((error = dlerror()) != NULL)
    {
        fputs(error, stderr);
        exit(EXIT_FAILURE);
    }

    freep(ptr);
    printf("free(%p)\n", ptr);
}

#endif