#define malloc(size) mymalloc(size)
#define free(ptr) myfree(ptr)
#include <sys/_types/_size_t.h>
void *mymalloc(size_t size);
void myfree(void* ptr);