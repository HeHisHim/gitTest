#include <stdio.h>

#define HOUSE_WIDTH 69
#define HOUSE_HEIGHT 26
#define WINDOW_WIDTH 11
#define WINDOW_HEIGHT 3

/* Reads from the input buffer.
 *
 * This is necessary because scanf() misbehaves inside of
 * looping constructs.
 *
 * Parameters:
 *   val -- pointer to memory storing input value
 *
 * Returns:
 *   0 if input is more than one character or non-numeric.
 *     In this case, the data pointed to by val is invalid.
 *
 *   1 otherwise
 */
int get_input(int *val)
{
    do
    {
        if ((*val = getchar()) == '\n')
            return 0;
    } while (getchar() != '\n');

    *val -= '0';

    if (*val >= 0 && *val <= 9)
        return 1;
    else
        return 0;
}

/* Prints the characters in the house array to the screen
 *
 * Parameters:
 *   house -- pointer characters representing the house
 *
 * Returns:
 *   Nothing
 */
void house_display(char *house)
{
    // int i, j;

    // for (j = 0; j < HOUSE_HEIGHT; j++, printf("\n"))
    //     for (i = 0; i < HOUSE_WIDTH; i++)
    //         printf("%c", house[HOUSE_WIDTH * j + i]);
    printf("%s\n", house);
}

void house_init (char* house, int* state)
{
    int control_arr[9][3] = {{642, 720, 798},
                             {657, 735, 813},
                             {672, 750, 828},
                             {1110, 1188, 1266},
                             {1125, 1203, 1281},
                             {1140, 1218, 1296},
                             {1578, 1656, 1734},
                             {1593, 1671, 1749},
                             {1608, 1686, 1764}
    };
    int x;
    int i;

    for(x = 0; x < 9; x++)
    {
        if(state[x])
        {
            for(i = 0; i < 3; i++)
            {
                for(int j = control_arr[x][i]; j < control_arr[x][i] + 5; j++)
                {
                    house[j] = '#';
                }
            }
        }
        else
        {
            for(i = 0; i < 3; i++)
            {
                for(int j = control_arr[x][i]; j < control_arr[x][i] + 5; j++)
                {
                    house[j] = ' ';
                }
            }
        }
    }
}

int solved (int* state)
{
    int x;

    for(x = 0; x < 9; x++)
    {
        if(state[x])
        {
            return 0;
        }
    }
    return 1;
}

void window_toggle (int* state, char* house, int choice)
{
    state[choice] = !state[choice];

    if(choice - 3 >= 0)
    {
        state[choice - 3] = !state[choice - 3];
    }
    if(choice + 3 <= 8)
    {
        state[choice + 3] = !state[choice + 3];
    }
    if( ((choice - 1) / 3 == choice / 3) && choice)
    {
        state[choice - 1] = !state[choice - 1];
    }
    if ( (choice + 1) / 3 == choice / 3 )
    {
        state[choice + 1] = !state[choice + 1];
    }

    house_init(house, state);
}


int main(int argc, char **argv)
{
    int choice;


    char house[] = {
        "\"                                                   ---------       \"\
        \n\"                                                  |         |      \"\
        \n\"                                                   ---------       \"\
        \n\"   ,______________________________________________|         |___,  \"\
        \n\"                                                  |_________|      \"\
        \n\"   |____________________________________________________________|  \"\
        \n\"   |               1              2              3              |  \"\
        \n\"   |           +-------+      +-------+      +-------+          |  \"\
        \n\"   |           |       |      |       |      |       |          |  \"\
        \n\"   |           |       |      |       |      |       |          |  \"\
        \n\"   |           |       |      |       |      |       |          |  \"\
        \n\"   |           +-------+      +-------+      +-------+          |  \"\
        \n\"   |               4              5              6              |  \"\
        \n\"   |           +-------+      +-------+      +-------+          |  \"\
        \n\"   |           |       |      |       |      |       |          |  \"\
        \n\"   |           |       |      |       |      |       |          |  \"\
        \n\"   |           |       |      |       |      |       |          |  \"\
        \n\"   |           +-------+      +-------+      +-------+          |  \"\
        \n\"   |               7              8              9              |  \"\
        \n\"   |           +-------+      +-------+      +-------+          |  \"\
        \n\"   |           |       |      |       |      |       |          |  \"\
        \n\"   |           |       |      |       |      |       |          |  \"\
        \n\"   |           |       |      |       |      |       |          |  \"\
        \n\"   |           +-------+      +-------+      +-------+          |  \"\
        \n\"   |                                                            |  \"\
        \n\"___________________________________________________________________\""
    };

        /* NOTE:
     * this will be our initial window state, do not change this!
     *   1 = Light is ON  -- fill with '#' character
     *   0 = Light is OFF -- fill with ' ' character (i.e. a space) */
    int state[] = { 1, 1, 0,
                    1, 0, 0,
                    0, 0, 0 };


    /* TODO: house[] needs to be updated to reflect initial
     *       values held in state[] */
    
    house_init (house, state);


    /* Infinite game loop.
     * (We will exit using 'break' when certain conditions are met) */
    while (1)
    {
        house_display(house);
        
        if (solved (state)) {
            printf ("Congratulations!  You won!\n");
            break;
        }

        printf("Choose a Window (0 to exit): ");
        if (!get_input(&choice))
        {
            printf("INVALID SELECTION!\n");
            continue;
        }

        if (!choice)
            break;
        
        choice--;
        window_toggle (state, house, choice);

    }

    printf("Goodbye!\n");

    return 0;
}
