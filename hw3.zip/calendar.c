#include <stdio.h>

int main(void)
{
    int days, startDay, x, y;

    printf("Enter number of days in month: ");
    scanf("%d", &days);

    printf("Enter starting day of the week (1 = Sun, 7 = Sat): ");
    scanf("%d", &startDay);

    for (x = 1; x < startDay; x++) {
        printf("   ");
    }
 
    for (y = 1; y <= days; x++, y++) {
        printf("%3d", y);
        if (x % 7 == 0)
            printf("\n");
    }
    
    printf("\n");

    return 0;
}