#include <stdio.h>

int main(int argc, char const *argv[])
{
    int number;
    int index = 0;
    int sample;

    printf("Enter a number: ");
    scanf("%d", &number);
    sample = number;

    while(sample)
    {
        sample /= 10;
        index++;
    }

    printf("The number %d has %d digits\n", number, index);

    return 0;
}
