#include <stdio.h>

int main(int argc, char const *argv[])
{
    int molecular, denominator, x, y, tmp;

    printf("Enter a fraction (x/y): ");
    scanf("%d/%d", &molecular, &denominator);

    x = molecular;
    y = denominator;

    while (y != 0) {
        tmp = x % y;
        x = y;
        y = tmp;
    }
    molecular /= x;
    denominator /= x;

    printf("In lowest terms: %d/%d\n", molecular, denominator);

    return 0;
}